﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Net;
using System.IO;

namespace TOPGames
{
    public partial class FormCliente : Form
    {
        public FormCliente()
        {
            InitializeComponent();
        }

        private void FormCliente_Load(object sender, EventArgs e)
        {
            Cliente cli = new Cliente();
            List<Cliente> clientes = cli.listacliente();
            dgvCliente.DataSource = clientes;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            try
            {
                Cliente cliente = new Cliente();
                cliente.Inserir(txtNome.Text, txtCelular.Text, dtpDtNascimento.Value, txtCep.Text, txtEndereco.Text, txtNumero.Text, txtCidade.Text, txtBairro.Text);
                MessageBox.Show("Cliente cadastrado com sucesso!", "Cadastro", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Cliente> cli = cliente.listacliente();
                dgvCliente.DataSource = cli;
                txtNome.Text = "";
                txtCelular.Text = "";
                this.dtpDtNascimento.Value = DateTime.Now.Date;
                txtCep.Text = "";
                txtEndereco.Text = "";
                txtNumero.Text = "";
                txtCidade.Text = "";
                txtBairro.Text = "";
                ClassConecta.FecharConexao();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(txtId.Text.Trim());
                Cliente cliente = new Cliente();
                cliente.Localiza(id);
                txtNome.Text = cliente.Nome;
                txtCelular.Text = cliente.Celular;
                dtpDtNascimento.Value = Convert.ToDateTime(cliente.Data_Nascimento);
                txtCep.Text = cliente.CEP;
                txtEndereco.Text = cliente.Endereço;
                txtNumero.Text = cliente.Número;
                txtCidade.Text = cliente.Cidade;
                txtBairro.Text = cliente.Bairro;
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(txtId.Text.Trim());
                Cliente cliente = new Cliente();
                cliente.Atualizar(id, txtNome.Text, txtCelular.Text, dtpDtNascimento.Value, txtCep.Text, txtEndereco.Text, txtNumero.Text, txtCidade.Text, txtBairro.Text);
                MessageBox.Show("Cliente atualizado com sucesso!", "Atualização", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Cliente> cli = cliente.listacliente();
                dgvCliente.DataSource = cli;
                txtId.Text = "";
                txtNome.Text = "";
                txtCelular.Text = "";
                this.dtpDtNascimento.Value = DateTime.Now.Date;
                txtCep.Text = "";
                txtEndereco.Text = "";
                txtNumero.Text = "";
                txtCidade.Text = "";
                txtBairro.Text = "";
                ClassConecta.FecharConexao();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(txtId.Text.Trim());
                Cliente cliente = new Cliente();
                cliente.Exclui(id);
                MessageBox.Show("Usuário excluído com sucesso!", "Exclusão", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Cliente> usu = cliente.listacliente();
                dgvCliente.DataSource = usu;
                txtId.Text = "";
                txtNome.Text = "";
                txtCelular.Text = "";
                this.dtpDtNascimento.Value = DateTime.Now.Date;
                txtCep.Text = "";
                txtEndereco.Text = "";
                txtNumero.Text = "";
                txtCidade.Text = "";
                txtBairro.Text = "";
                ClassConecta.FecharConexao();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create("https://viacep.com.br/ws/" + txtCep.Text + "/json");
            request.AllowAutoRedirect = false;
            HttpWebResponse ChecaServidor = (HttpWebResponse)request.GetResponse();
            if (ChecaServidor.StatusCode != HttpStatusCode.OK)
            {
                MessageBox.Show("Servidor Indisponível!");
                return; //Sai da rotina e para e codificação
            }
            using (Stream webStream = ChecaServidor.GetResponseStream())
            {
                if (webStream != null)
                {
                    using (StreamReader responseReader = new StreamReader(webStream))
                    {
                        string response = responseReader.ReadToEnd();
                        response = Regex.Replace(response, "[{},]", string.Empty);
                        response = response.Replace("\"", "");

                        String[] substrings = response.Split('\n');

                        int cont = 0;
                        foreach (var substring in substrings)
                        {
                            if (cont == 1)
                            {
                                string[] valor = substring.Split(":".ToCharArray());
                                if (valor[0] == "  erro")
                                {
                                    MessageBox.Show("CEP não encontrado!");
                                    txtCep.Focus();
                                    return;
                                }
                            }

                            //Endereço
                            if (cont == 2)
                            {
                                string[] valor = substring.Split(":".ToCharArray());
                                txtEndereco.Text = valor[1];
                            }

                            //Bairro
                            if (cont == 4)
                            {
                                string[] valor = substring.Split(":".ToCharArray());
                                txtBairro.Text = valor[1];
                            }

                            //Cidade
                            if (cont == 5)
                            {
                                string[] valor = substring.Split(":".ToCharArray());
                                txtCidade.Text = valor[1];
                            }
                            cont++;
                        }
                    }
                }
            }
        }

        private void btnLimpaCampos_Click(object sender, EventArgs e)
        {
            txtId.Text = "";
            txtNome.Text = "";
            txtCelular.Text = "";
            this.dtpDtNascimento.Value = DateTime.Now.Date;
            txtCep.Text = "";
            txtEndereco.Text = "";
            txtCidade.Text = "";
            txtBairro.Text = "";
        }

        private void dgvCliente_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow row = this.dgvCliente.Rows[e.RowIndex];
            txtId.Text = row.Cells[0].Value.ToString();
            txtNome.Text = row.Cells[1].Value.ToString();
            txtCelular.Text = row.Cells[2].Value.ToString();
            dtpDtNascimento.Text = row.Cells[3].Value.ToString();
            txtCep.Text = row.Cells[4].Value.ToString();
            txtEndereco.Text = row.Cells[5].Value.ToString();
            txtNumero.Text = row.Cells[6].Value.ToString();
            txtCidade.Text = row.Cells[7].Value.ToString();
            txtBairro.Text = row.Cells[8].Value.ToString();
        }
    }
}
